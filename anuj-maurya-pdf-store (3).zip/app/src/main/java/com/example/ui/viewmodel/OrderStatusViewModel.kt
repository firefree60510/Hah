package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppPreferences
import com.example.data.model.OrderItem
import com.example.data.repository.PdfRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class OrderStatusUiState(
    val orderIdInput: String = "",
    val whatsappInput: String = "",
    val isSearching: Boolean = false,
    val searchedOrder: OrderItem? = null,
    val errorMessage: String? = null,
    val infoMessage: String? = null
)

class OrderStatusViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = PdfRepository(application)
    private val preferences = AppPreferences(application)

    private val _uiState = MutableStateFlow(
        OrderStatusUiState(
            orderIdInput = preferences.lastOrderId,
            whatsappInput = preferences.whatsappNumber
        )
    )
    val uiState: StateFlow<OrderStatusUiState> = _uiState.asStateFlow()

    val savedOrders: StateFlow<List<OrderItem>> = repository.savedOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun onOrderIdChanged(id: String) {
        _uiState.update { it.copy(orderIdInput = id, errorMessage = null, infoMessage = null) }
    }

    fun onWhatsappChanged(phone: String) {
        _uiState.update { it.copy(whatsappInput = phone, errorMessage = null, infoMessage = null) }
    }

    fun searchOrder() {
        val orderId = _uiState.value.orderIdInput.trim()
        val phone = _uiState.value.whatsappInput.trim().replace("+91", "").replace(" ", "")

        if (orderId.isEmpty()) {
            _uiState.update { it.copy(errorMessage = "Please enter your Order ID (e.g. AMP-12345)") }
            return
        }

        if (phone.length < 10) {
            _uiState.update { it.copy(errorMessage = "Please enter your registered 10-digit WhatsApp number") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isSearching = true, errorMessage = null, infoMessage = null) }
            val result = repository.checkOrderStatus(orderId, phone)

            if (result.isSuccess) {
                _uiState.update {
                    it.copy(
                        isSearching = false,
                        searchedOrder = result.getOrNull()
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        isSearching = false,
                        errorMessage = result.exceptionOrNull()?.localizedMessage
                            ?: "No order found. Please check Order ID and WhatsApp number."
                    )
                }
            }
        }
    }

    fun selectSavedOrder(order: OrderItem) {
        _uiState.update {
            it.copy(
                orderIdInput = order.orderId,
                whatsappInput = order.whatsappNumber,
                searchedOrder = order,
                errorMessage = null
            )
        }
    }
}
