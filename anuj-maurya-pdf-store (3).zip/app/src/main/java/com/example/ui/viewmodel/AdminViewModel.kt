package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppPreferences
import com.example.data.model.AdminStats
import com.example.data.model.AppSettings
import com.example.data.model.OrderItem
import com.example.data.repository.PdfRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AdminUiState(
    val isLoggedIn: Boolean = false,
    val adminName: String = "Anuj Maurya",
    val isLoading: Boolean = false,
    val loginError: String? = null,
    val stats: AdminStats = AdminStats(),
    val orders: List<OrderItem> = emptyList(),
    val selectedFilter: String = "All", // "All", "Pending", "Approved", "Rejected"
    val appSettings: AppSettings = AppSettings(),
    val actionSuccessMessage: String? = null
)

class AdminViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = PdfRepository(application)
    private val preferences = AppPreferences(application)

    private val _uiState = MutableStateFlow(
        AdminUiState(
            isLoggedIn = preferences.isAdminLoggedIn,
            adminName = preferences.adminName
        )
    )
    val uiState: StateFlow<AdminUiState> = _uiState.asStateFlow()

    init {
        if (_uiState.value.isLoggedIn) {
            loadDashboardData()
        }
    }

    fun login(user: String, pass: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, loginError = null) }
            val result = repository.adminLogin(user, pass)
            if (result.isSuccess) {
                _uiState.update {
                    it.copy(
                        isLoggedIn = true,
                        adminName = preferences.adminName,
                        isLoading = false,
                        loginError = null
                    )
                }
                loadDashboardData()
            } else {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        loginError = result.exceptionOrNull()?.localizedMessage ?: "Invalid credentials"
                    )
                }
            }
        }
    }

    fun logout() {
        preferences.isAdminLoggedIn = false
        _uiState.update {
            it.copy(isLoggedIn = false, loginError = null)
        }
    }

    fun loadDashboardData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, actionSuccessMessage = null) }
            val settingsResult = repository.getSettings()
            val ordersResult = repository.getAdminOrders(_uiState.value.selectedFilter)

            val (stats, orders) = ordersResult.getOrDefault(Pair(AdminStats(), emptyList()))
            _uiState.update {
                it.copy(
                    isLoading = false,
                    stats = stats,
                    orders = orders,
                    appSettings = settingsResult.getOrDefault(AppSettings())
                )
            }
        }
    }

    fun filterOrders(status: String) {
        _uiState.update { it.copy(selectedFilter = status) }
        viewModelScope.launch {
            val ordersResult = repository.getAdminOrders(status)
            val (stats, orders) = ordersResult.getOrDefault(Pair(_uiState.value.stats, emptyList()))
            _uiState.update { it.copy(stats = stats, orders = orders) }
        }
    }

    fun updateOrderStatus(orderId: String, newStatus: String, message: String?) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            repository.updateAdminOrderStatus(orderId, newStatus, message)
            loadDashboardData()
            _uiState.update {
                it.copy(actionSuccessMessage = "Order $orderId updated to $newStatus")
            }
        }
    }

    fun saveSettings(upiId: String, upiName: String, announcement: String, whatsapp: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            repository.updateAdminSettings(upiId, upiName, announcement, whatsapp)
            loadDashboardData()
            _uiState.update {
                it.copy(actionSuccessMessage = "Payment details updated successfully!")
            }
        }
    }
}
