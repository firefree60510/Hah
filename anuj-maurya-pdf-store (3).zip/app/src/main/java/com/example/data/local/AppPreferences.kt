package com.example.data.local

import android.content.Context
import android.content.SharedPreferences

class AppPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("anuj_pdf_store_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_SERVER_URL = "key_server_url"
        private const val KEY_STUDENT_NAME = "key_student_name"
        private const val KEY_WHATSAPP = "key_whatsapp"
        private const val KEY_LAST_ORDER_ID = "key_last_order_id"
        private const val KEY_ADMIN_LOGGED_IN = "key_admin_logged_in"
        private const val KEY_ADMIN_NAME = "key_admin_name"
        // Default URL placeholder that user can customize
        const val DEFAULT_SERVER_URL = "https://anujmaurya.com/api/"
    }

    var isAdminLoggedIn: Boolean
        get() = prefs.getBoolean(KEY_ADMIN_LOGGED_IN, false)
        set(value) = prefs.edit().putBoolean(KEY_ADMIN_LOGGED_IN, value).apply()

    var adminName: String
        get() = prefs.getString(KEY_ADMIN_NAME, "Anuj Maurya") ?: "Anuj Maurya"
        set(value) = prefs.edit().putString(KEY_ADMIN_NAME, value).apply()

    var serverUrl: String
        get() = prefs.getString(KEY_SERVER_URL, DEFAULT_SERVER_URL) ?: DEFAULT_SERVER_URL
        set(value) = prefs.edit().putString(KEY_SERVER_URL, value.trim().let {
            if (it.endsWith("/")) it else "$it/"
        }).apply()

    var studentName: String
        get() = prefs.getString(KEY_STUDENT_NAME, "") ?: ""
        set(value) = prefs.edit().putString(KEY_STUDENT_NAME, value).apply()

    var whatsappNumber: String
        get() = prefs.getString(KEY_WHATSAPP, "") ?: ""
        set(value) = prefs.edit().putString(KEY_WHATSAPP, value).apply()

    var lastOrderId: String
        get() = prefs.getString(KEY_LAST_ORDER_ID, "") ?: ""
        set(value) = prefs.edit().putString(KEY_LAST_ORDER_ID, value).apply()
}
