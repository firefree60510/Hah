<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json; charset=UTF-8');

$orderId        = isset($_GET['order_id']) ? trim($_GET['order_id']) : '';
$whatsappNumber = isset($_GET['whatsapp_number']) ? trim($_GET['whatsapp_number']) : '';

if (empty($orderId) || empty($whatsappNumber)) {
    sendJsonResponse([
        'success' => false,
        'message' => 'Both Order ID and WhatsApp number are required to verify access.'
    ], 400);
}

$cleanPhone = preg_replace('/[^0-9]/', '', $whatsappNumber);

try {
    $db = getDbConnection();
    // Security: Only return order if BOTH order_id and whatsapp_number match!
    $stmt = $db->prepare(
        "SELECT o.`order_id`, o.`pdf_id`, o.`pdf_title`, o.`pdf_price`, o.`student_name`, 
                o.`whatsapp_number`, o.`utr_number`, o.`screenshot_url`, o.`status`, 
                o.`status_message`, o.`created_at`, p.`download_url` AS `pdf_file_url` 
         FROM `orders` o 
         LEFT JOIN `pdfs` p ON o.`pdf_id` = p.`id` 
         WHERE o.`order_id` = :order_id AND o.`whatsapp_number` = :whatsapp_number 
         LIMIT 1"
    );
    $stmt->execute([
        ':order_id'        => $orderId,
        ':whatsapp_number' => $cleanPhone
    ]);
    $order = $stmt->fetch();

    if (!$order) {
        sendJsonResponse([
            'success' => false,
            'message' => 'No order found matching the provided Order ID and WhatsApp number.'
        ], 404);
    }

    $isApproved = in_array(strtolower($order['status']), ['approved', 'delivered']);

    sendJsonResponse([
        'success' => true,
        'data' => [
            'order_id'        => $order['order_id'],
            'pdf_id'          => (int)$order['pdf_id'],
            'pdf_title'       => $order['pdf_title'],
            'pdf_price'       => (float)$order['pdf_price'],
            'student_name'    => $order['student_name'],
            'whatsapp_number' => $order['whatsapp_number'],
            'utr_number'      => $order['utr_number'],
            'screenshot_url'  => $order['screenshot_url'],
            'status'          => $order['status'],
            'status_message'  => $order['status_message'],
            // Security: Only expose download link if order is approved by admin!
            'download_url'    => $isApproved ? ($order['pdf_file_url'] ?: "https://anujmaurya.com/download.php?order=" . urlencode($order['order_id'])) : null,
            'created_at'      => $order['created_at']
        ]
    ]);

} catch (Exception $e) {
    sendJsonResponse([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ], 500);
}
