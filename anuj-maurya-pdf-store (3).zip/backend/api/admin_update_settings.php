<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json; charset=UTF-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(['success' => false, 'message' => 'POST method required'], 405);
}

$input = json_decode(file_get_contents('php://input'), true);

$upiId = isset($input['upi_id']) ? trim($input['upi_id']) : (isset($_POST['upi_id']) ? trim($_POST['upi_id']) : '');
$upiName = isset($input['upi_name']) ? trim($input['upi_name']) : (isset($_POST['upi_name']) ? trim($_POST['upi_name']) : '');
$announcement = isset($input['announcement']) ? trim($input['announcement']) : (isset($_POST['announcement']) ? trim($_POST['announcement']) : '');
$whatsapp = isset($input['whatsapp_number']) ? trim($input['whatsapp_number']) : (isset($_POST['whatsapp_number']) ? trim($_POST['whatsapp_number']) : '');
$upiQrUrl = isset($input['upi_qr_url']) ? trim($input['upi_qr_url']) : (isset($_POST['upi_qr_url']) ? trim($_POST['upi_qr_url']) : '');

try {
    $db = getDbConnection();
    $stmt = $db->prepare(
        "UPDATE `app_settings` 
         SET `upi_id` = COALESCE(NULLIF(:upi_id, ''), `upi_id`),
             `upi_name` = COALESCE(NULLIF(:upi_name, ''), `upi_name`),
             `announcement` = COALESCE(NULLIF(:announcement, ''), `announcement`),
             `whatsapp_number` = COALESCE(NULLIF(:whatsapp_number, ''), `whatsapp_number`),
             `upi_qr_url` = COALESCE(NULLIF(:upi_qr_url, ''), `upi_qr_url`)
         WHERE `id` = 1"
    );
    $stmt->execute([
        ':upi_id' => $upiId,
        ':upi_name' => $upiName,
        ':announcement' => $announcement,
        ':whatsapp_number' => $whatsapp,
        ':upi_qr_url' => $upiQrUrl
    ]);

    sendJsonResponse([
        'success' => true,
        'message' => 'Settings updated successfully'
    ]);
} catch (Exception $e) {
    sendJsonResponse(['success' => false, 'message' => 'Database error: ' . $e->getMessage()], 500);
}
