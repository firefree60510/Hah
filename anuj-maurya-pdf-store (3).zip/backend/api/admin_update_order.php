<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json; charset=UTF-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJsonResponse(['success' => false, 'message' => 'POST method required'], 405);
}

$input = json_decode(file_get_contents('php://input'), true);
$orderId = isset($input['order_id']) ? trim($input['order_id']) : (isset($_POST['order_id']) ? trim($_POST['order_id']) : '');
$status  = isset($input['status']) ? trim($input['status']) : (isset($_POST['status']) ? trim($_POST['status']) : '');
$message = isset($input['status_message']) ? trim($input['status_message']) : (isset($_POST['status_message']) ? trim($_POST['status_message']) : null);
$downloadUrl = isset($input['download_url']) ? trim($input['download_url']) : (isset($_POST['download_url']) ? trim($_POST['download_url']) : null);

if (empty($orderId) || empty($status)) {
    sendJsonResponse(['success' => false, 'message' => 'order_id and status are required'], 400);
}

try {
    $db = getDbConnection();
    
    // Auto message if not provided
    if (empty($message)) {
        if ($status === 'Approved') {
            $message = 'Payment verified successfully! You can now download your PDF.';
        } elseif ($status === 'Rejected') {
            $message = 'Payment could not be verified. Please check UTR or contact admin.';
        }
    }

    $stmt = $db->prepare(
        "UPDATE `orders` 
         SET `status` = :status, 
             `status_message` = :status_message, 
             `download_url` = COALESCE(:download_url, `download_url`),
             `updated_at` = CURRENT_TIMESTAMP 
         WHERE `order_id` = :order_id"
    );
    $stmt->execute([
        ':status' => $status,
        ':status_message' => $message,
        ':download_url' => $downloadUrl,
        ':order_id' => $orderId
    ]);

    sendJsonResponse([
        'success' => true,
        'message' => "Order $orderId status updated to $status"
    ]);
} catch (Exception $e) {
    sendJsonResponse(['success' => false, 'message' => 'Database error: ' . $e->getMessage()], 500);
}
