<?php
require_once __DIR__ . '/../config/db.php';

header('Content-Type: application/json; charset=UTF-8');

try {
    $db = getDbConnection();

    $boardClass = isset($_GET['class']) ? trim($_GET['class']) : '';
    $category   = isset($_GET['category']) ? trim($_GET['category']) : '';
    $search     = isset($_GET['search']) ? trim($_GET['search']) : '';

    $whereClauses = ["`is_available` = 1"];
    $params = [];

    if (!empty($boardClass) && strtolower($boardClass) !== 'all') {
        $whereClauses[] = "`board_class` = :board_class";
        $params[':board_class'] = $boardClass;
    }

    if (!empty($category) && strtolower($category) !== 'all') {
        $whereClauses[] = "`category` = :category";
        $params[':category'] = $category;
    }

    if (!empty($search)) {
        $whereClauses[] = "(`title` LIKE :search OR `subject` LIKE :search OR `description` LIKE :search)";
        $params[':search'] = '%' . $search . '%';
    }

    $sql = "SELECT `id`, `title`, `board_class`, `subject`, `category`, `price`, `original_price`, 
                   `description`, `preview_image_url`, `pages_count`, `file_size`, `year`, 
                   `is_available`, `is_featured`, `sample_preview_url` 
            FROM `pdfs` 
            WHERE " . implode(' AND ', $whereClauses) . " 
            ORDER BY `is_featured` DESC, `id` DESC";

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $pdfs = $stmt->fetchAll();

    // Cast types properly
    $formatted = array_map(function($row) {
        return [
            'id' => (int)$row['id'],
            'title' => $row['title'],
            'board_class' => $row['board_class'],
            'subject' => $row['subject'],
            'category' => $row['category'],
            'price' => (float)$row['price'],
            'original_price' => $row['original_price'] !== null ? (float)$row['original_price'] : null,
            'description' => $row['description'],
            'preview_image_url' => $row['preview_image_url'],
            'pages_count' => (int)$row['pages_count'],
            'file_size' => $row['file_size'],
            'year' => $row['year'],
            'is_available' => (bool)$row['is_available'],
            'is_featured' => (bool)$row['is_featured'],
            'sample_preview_url' => $row['sample_preview_url'],
            'download_url' => null // Security: Never expose download link in general listing!
        ];
    }, $pdfs);

    sendJsonResponse([
        'success' => true,
        'count' => count($formatted),
        'data' => $formatted
    ]);

} catch (Exception $e) {
    sendJsonResponse([
        'success' => false,
        'message' => 'Error retrieving PDFs: ' . $e->getMessage()
    ], 500);
}
