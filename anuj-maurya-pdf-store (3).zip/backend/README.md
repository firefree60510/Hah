# Anuj Maurya PDF Store - Backend Setup Guide

This backend powers both the **Student Android App** and the upcoming **Admin Android App**.

---

## 1. Requirements

- PHP 7.4+ or PHP 8.0+
- MySQL 5.7+ or MariaDB 10.3+
- PHP `cURL` extension (for ImgBB API uploads)
- PHP `PDO` and `pdo_mysql` extensions
- PHP `fileinfo` extension (for image MIME type validation)

---

## 2. Database Installation

1. Open your MySQL client (e.g. phpMyAdmin, MySQL Workbench, or CLI).
2. Create a database named `anuj_pdf_store`:
   ```sql
   CREATE DATABASE anuj_pdf_store CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```
3. Import the provided schema:
   ```bash
   mysql -u root -p anuj_pdf_store < database.sql
   ```
4. This creates tables for `app_settings`, `pdfs` (pre-populated with UP Board Class 9 & 10 study materials), `orders`, and `admin_users`.

---

## 3. Server Configuration & ImgBB API Key

1. Copy `.env.example` to `.env` in the backend root directory:
   ```bash
   cp .env.example .env
   ```
2. Open `.env` and fill in your credentials:
   ```ini
   DB_HOST=localhost
   DB_NAME=anuj_pdf_store
   DB_USER=your_db_username
   DB_PASS=your_db_password

   # Put your free ImgBB API Key here:
   IMG_BB_API_KEY=YOUR_ACTUAL_IMGBB_API_KEY

   # Base URL where your backend is hosted:
   BASE_URL=https://your-domain.com/backend/
   ```
3. Get your free ImgBB API Key at: [https://api.imgbb.com/](https://api.imgbb.com/)

---

## 4. API Endpoints

- `GET /api/settings.php`: Returns dynamic app settings (UPI ID, QR URL, announcement banner, WhatsApp, YouTube, Telegram).
- `GET /api/pdfs.php?class=Class+10&category=Notes&search=Math`: Returns list of UP Board study materials with search and filters.
- `GET /api/pdf_details.php?id=101`: Returns full details of a specific PDF.
- `POST /api/upload_order.php`: Multipart form upload (`screenshot`, `pdf_id`, `student_name`, `whatsapp_number`, `utr_number`). Securely uploads screenshot to ImgBB and records order in MySQL.
- `GET /api/order_status.php?order_id=AMP-XXXX&whatsapp_number=9876543210`: Returns order verification status. If status is `Approved`, returns download URL.
- `POST /api/admin_login.php`: Admin authentication (Default: `anuj_admin` / `admin123`).
- `GET /api/admin_orders.php?status=Pending`: List student orders with stats (Total orders, pending, approved, revenue).
- `POST /api/admin_update_order.php`: Approve or reject orders and unlock PDF downloads.
- `POST /api/admin_update_settings.php`: Update receiving UPI ID, receiver name, WhatsApp number, and marquee announcements.

---

## 5. Connecting the Student Android App

In the Android App:
1. Tap the **Server Settings** icon (server icon in the top right corner of the Home Screen).
2. Enter your live backend URL (e.g., `https://your-domain.com/backend/api/` or `http://10.0.2.2/backend/api/` for Android Emulator localhost).
3. Tap **Save & Connect**.
4. The app will immediately load live PDFs and settings from your MySQL database!
