-- ======================================================
-- Anuj Maurya PDF Store - MySQL Database Schema
-- Compatible with MySQL 5.7+ and MySQL 8.0+ / MariaDB
-- ======================================================

CREATE DATABASE IF NOT EXISTS `anuj_pdf_store` 
  DEFAULT CHARACTER SET utf8mb4 
  COLLATE utf8mb4_unicode_ci;

USE `anuj_pdf_store`;

-- ------------------------------------------------------
-- Table: app_settings
-- Stores admin UPI ID, QR URL, social links & announcements
-- ------------------------------------------------------
CREATE TABLE IF NOT EXISTS `app_settings` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `app_name` VARCHAR(100) NOT NULL DEFAULT 'Anuj Maurya PDF Store',
  `announcement` TEXT NULL,
  `home_banner_url` VARCHAR(255) NULL,
  `upi_id` VARCHAR(100) NOT NULL DEFAULT 'anujmaurya@upi',
  `upi_name` VARCHAR(100) NOT NULL DEFAULT 'Anuj Maurya',
  `upi_qr_url` VARCHAR(255) NULL,
  `whatsapp_number` VARCHAR(20) NOT NULL DEFAULT '919876543210',
  `youtube_url` VARCHAR(255) NOT NULL DEFAULT 'https://youtube.com/@anujmauryapdf',
  `telegram_url` VARCHAR(255) NOT NULL DEFAULT 'https://t.me/anujmauryapdf',
  `payment_instructions` TEXT NOT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert initial default settings
INSERT INTO `app_settings` (`id`, `app_name`, `announcement`, `home_banner_url`, `upi_id`, `upi_name`, `upi_qr_url`, `whatsapp_number`, `youtube_url`, `telegram_url`, `payment_instructions`)
VALUES (
  1,
  'Anuj Maurya PDF Store',
  'UP Board Exam 2025-26 Special: Class 9 & Class 10 Model Papers, Notes & Important Questions are now available!',
  '',
  'anujmaurya@upi',
  'Anuj Maurya',
  '',
  '919876543210',
  'https://youtube.com/@anujmauryapdf',
  'https://t.me/anujmauryapdf',
  '1. Pay the exact PDF price using the UPI ID or QR Code.\n2. Take a screenshot of the successful transaction.\n3. Upload screenshot with your WhatsApp number.\n4. Admin will manually verify and approve your order within 1-2 hours.'
) ON DUPLICATE KEY UPDATE `app_name` = VALUES(`app_name`);

-- ------------------------------------------------------
-- Table: pdfs
-- Stores UP Board study materials catalog
-- ------------------------------------------------------
CREATE TABLE IF NOT EXISTS `pdfs` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `board_class` VARCHAR(20) NOT NULL, -- 'Class 9', 'Class 10'
  `subject` VARCHAR(50) NOT NULL,     -- 'Mathematics', 'Science', 'Hindi', etc.
  `category` VARCHAR(50) NOT NULL,    -- 'Notes', 'Important Papers', 'Model Papers', 'Previous Year Papers', 'Important Questions'
  `price` DECIMAL(10,2) NOT NULL,
  `original_price` DECIMAL(10,2) NULL,
  `description` TEXT NULL,
  `preview_image_url` VARCHAR(255) NULL,
  `pages_count` INT DEFAULT 0,
  `file_size` VARCHAR(30) NULL,
  `year` VARCHAR(20) DEFAULT '2025-26',
  `is_available` TINYINT(1) DEFAULT 1,
  `is_featured` TINYINT(1) DEFAULT 0,
  `sample_preview_url` VARCHAR(255) NULL,
  `pdf_file_path` VARCHAR(255) NULL,  -- Secure internal server path to paid PDF
  `download_url` VARCHAR(255) NULL,   -- Public access link when approved
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX (`board_class`),
  INDEX (`category`),
  INDEX (`is_available`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Populate default Class 9 & Class 10 PDFs
INSERT INTO `pdfs` (`id`, `title`, `board_class`, `subject`, `category`, `price`, `original_price`, `description`, `pages_count`, `file_size`, `year`, `is_available`, `is_featured`, `download_url`) VALUES
(101, 'कक्षा 10 गणित - सम्पूर्ण अध्याय हस्तलिखित नोट्स (Handwritten Notes)', 'Class 10', 'Mathematics', 'Notes', 49.00, 149.00, 'UP Board कक्षा 10 गणित के सभी 14 अध्यायों के सरल एवं स्पष्ट हस्तलिखित नोट्स। इसमें सूत्र संग्रह, महत्वपूर्ण प्रमेय, उदाहरण एवं अभ्यास प्रश्न शामिल हैं।', 120, '14.2 MB', '2025-26', 1, 1, 'https://anujmaurya.com/files/class10_math_notes.pdf'),
(102, 'कक्षा 10 विज्ञान - बोर्ड परीक्षा 2026 मॉडल पेपर (Set 1 to 5)', 'Class 10', 'Science', 'Model Papers', 39.00, 99.00, 'नवीनतम UP Board परीक्षा पैटर्न पर आधारित विज्ञान के 5 हल सहित मॉडल प्रश्न पत्र। भौतिक, रसायन और जीव विज्ञान के अति-महत्वपूर्ण प्रश्न।', 65, '8.6 MB', '2025-26', 1, 1, 'https://anujmaurya.com/files/class10_science_model.pdf'),
(103, 'कक्षा 10 हिंदी - पिछले 5 वर्षों के बोर्ड प्रश्न पत्र (2020-2024 Solved)', 'Class 10', 'Hindi', 'Previous Year Papers', 29.00, 79.00, 'UP Board कक्षा 10 सामान्य हिंदी के विगत 5 वर्षों के वास्तविक प्रश्न पत्र एवं पूर्ण आदर्श उत्तर। गद्य, पद्य एवं संस्कृत खंड सहित।', 85, '9.1 MB', '2020-2024', 1, 0, 'https://anujmaurya.com/files/class10_hindi_pyq.pdf'),
(104, 'कक्षा 10 सामाजिक विज्ञान - 100 महत्वपूर्ण प्रश्न उत्तर (High Scoring)', 'Class 10', 'Social Science', 'Important Questions', 35.00, 89.00, 'इतिहास, भूगोल, नागरिक शास्त्र एवं अर्थशास्त्र के शीर्ष 100 बहुविकल्पीय एवं विस्तृत उत्तरीय प्रश्न। मानचित्र कार्य के विशेष टिप्स।', 72, '7.8 MB', '2025-26', 1, 1, 'https://anujmaurya.com/files/class10_sst_imp.pdf'),
(105, 'कक्षा 10 अंग्रेज़ी - Grammar & Literature Short Notes', 'Class 10', 'English', 'Notes', 39.00, 99.00, 'Class 10 English First Flight & Footprints without Feet chapter summaries, key questions, character sketches, and grammar practice sets.', 94, '11.0 MB', '2025-26', 1, 0, 'https://anujmaurya.com/files/class10_english_notes.pdf'),
(106, 'कक्षा 10 गणित - वायरल महत्वपूर्ण प्रश्न पत्र (Pre-Board Special)', 'Class 10', 'Mathematics', 'Important Papers', 29.00, 69.00, 'बोर्ड परीक्षा में 70/70 अंक हासिल करने हेतु तैयार किया गया विशेष प्रश्न पत्र। इसमें त्रिकोणमिति, पृष्ठीय क्षेत्रफल और द्विघात समीकरण के पक्के प्रश्न हैं।', 42, '5.3 MB', '2025-26', 1, 1, 'https://anujmaurya.com/files/class10_math_imp_paper.pdf'),
(201, 'कक्षा 9 विज्ञान - NCERT आधारित सम्पूर्ण नोट्स एवं आरेख (Diagrams)', 'Class 9', 'Science', 'Notes', 39.00, 89.00, 'कक्षा 9 विज्ञान के सभी अध्यायों के रंगीन आरेख सहित सम्पूर्ण थ्योरी नोट्स। गति, बल, गुरुत्वाकर्षण, परमाणु एवं अणु के सरल नोट्स।', 110, '13.5 MB', '2025-26', 1, 1, 'https://anujmaurya.com/files/class9_science_notes.pdf'),
(202, 'कक्षा 9 गणित - वार्षिक परीक्षा 2026 हेतु मॉडल पेपर्स (3 Solved)', 'Class 9', 'Mathematics', 'Model Papers', 29.00, 69.00, 'UP Board कक्षा 9 गणित वार्षिक परीक्षा के लिए विशेषज्ञ शिक्षकों द्वारा तैयार किए गए 3 सम्पूर्ण हल सहित मॉडल पेपर।', 48, '6.2 MB', '2025-26', 1, 0, 'https://anujmaurya.com/files/class9_math_model.pdf'),
(203, 'कक्षा 9 हिंदी - वार्षिक परीक्षा महत्वपूर्ण प्रश्न एवं व्याकरण', 'Class 9', 'Hindi', 'Important Questions', 25.00, 59.00, 'कक्षा 9 हिंदी के महत्वपूर्ण पद्यांश, गद्यांश व्याख्या, संस्कृत खंड अनुवाद एवं संधि, समास, मुहावरे के चुनिंदा प्रश्न।', 55, '5.9 MB', '2025-26', 1, 0, 'https://anujmaurya.com/files/class9_hindi_imp.pdf'),
(204, 'कक्षा 9 सामाजिक विज्ञान - सम्पूर्ण अध्याय सार एवं प्रश्न उत्तर', 'Class 9', 'Social Science', 'Notes', 35.00, 79.00, 'फ्रांसीसी क्रांति, भारत का आकार और स्थिति, संविधान निर्माण एवं पालमपुर गाँव की कहानी के परीक्षा-उपयोगी नोट्स।', 80, '9.4 MB', '2025-26', 1, 0, 'https://anujmaurya.com/files/class9_sst_notes.pdf'),
(205, 'कक्षा 9 एवं 10 संस्कृत - व्याकरण, श्लोक अर्थ एवं आदर्श प्रश्न पत्र', 'Class 10', 'Sanskrit', 'Important Papers', 29.00, 69.00, 'UP Board संस्कृत के महत्वपूर्ण सूक्ति, श्लोक संदर्भ-सहित हिंदी अनुवाद एवं शब्दरूप, धातुरूप संग्रह।', 50, '6.1 MB', '2025-26', 1, 0, 'https://anujmaurya.com/files/sanskrit_board_prep.pdf')
ON DUPLICATE KEY UPDATE `title` = VALUES(`title`);

-- ------------------------------------------------------
-- Table: orders
-- Stores student purchase requests with ImgBB screenshot
-- ------------------------------------------------------
CREATE TABLE IF NOT EXISTS `orders` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `order_id` VARCHAR(50) NOT NULL UNIQUE,
  `pdf_id` BIGINT NOT NULL,
  `pdf_title` VARCHAR(255) NOT NULL,
  `pdf_price` DECIMAL(10,2) NOT NULL,
  `student_name` VARCHAR(100) NOT NULL,
  `whatsapp_number` VARCHAR(20) NOT NULL,
  `utr_number` VARCHAR(100) NULL,
  `screenshot_url` VARCHAR(500) NOT NULL,
  `screenshot_delete_url` VARCHAR(500) NULL, -- Hidden from students
  `status` ENUM('Pending', 'Approved', 'Rejected', 'Delivered') DEFAULT 'Pending',
  `status_message` VARCHAR(255) DEFAULT 'Order received. Pending manual UPI verification by Admin.',
  `download_url` VARCHAR(255) NULL,
  `admin_notes` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX (`order_id`),
  INDEX (`whatsapp_number`),
  INDEX (`status`),
  CONSTRAINT `fk_orders_pdf` FOREIGN KEY (`pdf_id`) REFERENCES `pdfs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------
-- Table: admin_users
-- For the upcoming Admin Android App authentication
-- ------------------------------------------------------
CREATE TABLE IF NOT EXISTS `admin_users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(100) NOT NULL DEFAULT 'Anuj Maurya',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Default admin user: admin / admin123 (Change password immediately in production!)
INSERT INTO `admin_users` (`id`, `username`, `password_hash`, `full_name`)
VALUES (1, 'anuj_admin', '$2y$10$wK1.wU6Xl4F7Qz1t3E9iPeQ1e3IeF4e3yL1Y0u8q9W1v2e3r4t5y6', 'Anuj Maurya')
ON DUPLICATE KEY UPDATE `username` = VALUES(`username`);
